# htmlpartesgaleriadearte
Repositorio HTML Partes Evaluación Unidad 1. Taller de Tecnologías WEB. Profesor Justo Vargas.

- Se sube la versión preliminar de index.html con la sección de inicio. 
- Se sube la versión preliminar de galeriadefotos.html con la sección de galería de fotos.